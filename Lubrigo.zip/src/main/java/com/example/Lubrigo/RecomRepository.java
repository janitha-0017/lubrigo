package com.example.Lubrigo;

public class RecomRepository {
}
